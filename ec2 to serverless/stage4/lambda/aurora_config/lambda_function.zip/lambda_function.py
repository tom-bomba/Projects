import logging
import pymysql
import json

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.info('This is an INFO message')
logger.error('This is an ERROR message')
print('here')
app_db_name = "fortunes"
app_app_table_name ="fortunes"
aws_secret_location = "dev/db_creds/webserver_v2"

def create_tables(rds_endpoint, db_username, db_password):
    logger.info("Creating tables...")
    try:
        connection = pymysql.connect(host=rds_endpoint,
                                     user=db_username,
                                     password=db_password,
                                     db=app_db_name,
                                     cursorclass=pymysql.cursors.DictCursor)
    except pymysql.MySQLError as e:
        logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
        logger.error(e)
        return

    try:
        with connection.cursor() as cursor:
            logger.info("Creating App table...")
            sql = f"""CREATE TABLE if not exists {app_app_table_name} (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL,
                        fortune TEXT NOT NULL
                      );"""
            cursor.execute(sql)

        connection.commit()
    finally:
        connection.close()

def lambda_handler(event, context):
    rds_endpoint = event['rds_endpoint']
    db_username = event['db_username']
    db_password = event['db_password']
    logger.info(f"Received event: {json.dumps(event, indent=2)}")
    logger.info(f"Using RDS endpoint: {rds_endpoint}")
    create_tables(rds_endpoint, db_username, db_password)
    return {
        'statusCode': 200,
        'body': json.dumps('Tables created successfully')
    }
